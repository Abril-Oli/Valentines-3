import { useState } from "react";

import "./App.css";

//var constante para las frases a mostrar//

const phrases = [
  "No",
  "no mala",
  "Are you sure pork?",
  "REALLY REALLY SURE PORKITO MALO?",
  "Enserio cutie pie?",
  "Te voy a pegar porkychips",
  "VOY A LLORAR PUERCO MALO",
];
//function para contadores y que ocurre cuando se presiona Si o no //
function App() {
  const [noCount, setNoCount] = useState(0);
  const [yesPressed, setYesPressed] = useState(false);
  //calculo para el tamaño de los botones//
  const yesButtonSize = noCount * 20 + 16;

  //function de incremento//
  function handleNoClick() {
    setNoCount(noCount + 1);
  }

  //function de decremento para devolver las frases personalizadas//
  function getNoButtonText() {
    return phrases[Math.min(noCount, phrases.length - 1)];
  }

  return (
    <div className="valentines-container">
      {yesPressed ? (
        <>
          <img
            alt="porkytos"
            src="https://i.pinimg.com/originals/c5/3f/a4/c53fa4159c9ddb1e06d3572c88b163b5.gif"
          />

          <div className="textYes">
            {" "}
            YES HONEYBOBOO, te amo, lets get breakfast!!!! 🌷🌸🎀🌷🌸🌷{" "}
          </div>
        </>
      ) : (
        <>
          <img
            alt="valentines portada"
            src="https://i.pinimg.com/originals/36/65/b2/3665b227058f4b901e62401c696bae41.gif"
          />

          <div className="textValentines"> Queres ser mi San Valentin? </div>
          <div>
            <button
              className="yesButton"
              style={{ fontSize: yesButtonSize }}
              onClick={() => setYesPressed(true)}
            >
              Si
            </button>
            <button onClick={handleNoClick} className="noButton">
              {getNoButtonText()}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default App;
